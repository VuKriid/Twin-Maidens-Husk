module.exports = (message) => {
    if(message.author.bot)  return;
    
    if(message.content === '<@932708550684323841>') {
        message.reply('```\nLas Doncellas Gemelas alzan sus manos lentamente sugiriendo que esperes en silencio.\n```')
    }
}